import { Link } from "react-router-dom";

export default function EssentialsPreview({ trip }) {
  if (!trip) return null;

  const items = [
    { icon: "🏥", name: "Hospitals" },
    { icon: "💊", name: "Pharmacy" },
    { icon: "🏧", name: "ATM" },
    { icon: "⛽", name: "Petrol Pump" },
    { icon: "👮", name: "Police" },
    { icon: "🔧", name: "Mechanic" },
  ];

  return (
    <section className="rounded-3xl bg-white p-6 shadow-lg">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold translate-x-3">Essentials Nearby</h2>
          <p className="text-gray-500 translate-x-3">
            Find important places around {trip.destination}
          </p>
        </div>

        <Link
          to="/essentials"
          state={{ destination: trip.destination }}
          className="rounded-xl bg-indigo-600 px-5 py-2 text-white hover:bg-indigo-700"
        >
          View All
        </Link>
      </div>

      <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-6">
        {items.map((item) => (
          <div
            key={item.name}
            className="rounded-2xl border bg-gray-50 p-5 text-center transition hover:shadow-md"
          >
            <div className="text-4xl">{item.icon}</div>

            <p className="mt-3 font-semibold">{item.name}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
